# LMS-shoutcast

3rd party Plugin für the Logitech Media Server to play shoutcast streams without a mysqueezebox.com account 

To Install:

##Alternative 1:

Open the LMS GUI; click on Settings, then select the Plugins tab, at the bottom of the page add the repo:

http://raw.githubusercontent.com/oweitman/LMS-shoutcast/master/public.xml

Next install the plugin and enable as usual.

OR

##Alternative2

1. download the source
2. check on the information-page in the LMS-settings for your plugin-folders
3. in the plugin-folder create a new directory named "NewShoutcast"
4. copy the downloaded source in this directory
5. restart LMS

For Diskussion, errors and feature requests:
http://forums.slimdevices.com/showthread.php?105756-3rd-Party-Shoutcast-Plugin

